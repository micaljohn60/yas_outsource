<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <script src="https://kit.fontawesome.com/0e4c6fcdab.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/loginstyle.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/credit_card.css')); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script
    src="https://code.jquery.com/jquery-3.6.1.js"
    integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI="
    crossorigin="anonymous"></script>
    <!-- Style -->
    

    <title>Register in to Outsource</title>
</head>

<body>
    <?php
    $isFreeUser = true;
    ?>

    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>
    <div class="d-lg-flex half">

        <div <?php if($isFreeUser): ?> class="d-flex justify-content-center align-items-center col-lg-12" <?php else: ?> class="bg order-1 order-md-2 d-flex justify-centent-center align-items-center border border-right" <?php endif; ?> >

            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-md-7">
                        <h3><strong>Create New Account </strong></h3>
                        <p class="mb-4">Lorem ipsum dolor sit amet elit. Sapiente sit aut eos consectetur adipisicing.
                        </p>

                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group last mb-3">
                                        <label for="firstName">Frist Name</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="first_name" required autocomplete="type" placeholder="First name"
                                            value="<?php echo e(old('first_name')); ?>"
                                            id="firstName">
                                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group last mb-3">
                                        <label for="lastName">Last Name</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="last_name" required autocomplete="current-password" placeholder="Last Name"
                                            id="last_name">
                                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group first">
                                <label for="username"><?php echo e(__('Email Address')); ?></label>
                                <input type="email" class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"
                                    placeholder="your-email@gmail.com" id="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group last mb-3 mt-3">
                                <label for="password"><?php echo e(__('Password')); ?></label>
                                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="password" required autocomplete="current-password" placeholder="Your Password"
                                    id="password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="form-group last mb-3">
                                <label for="password"><?php echo e(__('Re-Type Password')); ?></label>
                                <input type="password" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="password_confirmation" required autocomplete="new-password" placeholder="Your Password"
                                    id="password_confirmation">

                            </div>

                            <div class="form-group last mb-3">
                                <select class="form-select" aria-label="Default select example" name="type">
                                    <option value="buyer">Buyer</option>
                                    <option value="seller">Seller</option>
                                    <option value="expert">Expert</option>
                                  </select>

                                <input type="hidden" name="access_type" <?php if($isFreeUser): ?> value="FREE" <?php else: ?> value="PREMIUM" <?php endif; ?>>
                            </div>



                            <div class="d-flex mb-5 align-items-center">
                                <label class="control control--checkbox mb-0" for="remember"><span class="caption">

                                        <?php echo e(__('Remember Me')); ?>


                                    </span>
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                        <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <div class="control__indicator"></div>
                                </label>
                                

                            </div>

                            <button type="submit" <?php if($isFreeUser): ?> class="btn btn-block btn-primary" <?php else: ?> class="d-none" <?php endif; ?> >
                                <?php echo e(__('Register')); ?>

                            </button>


                    </div>
                </div>
            </div>
        </div>

        <div <?php if($isFreeUser): ?> class="d-none" <?php else: ?> class="bg order-1 order-md-2 d-flex justify-centent-center align-items-center" <?php endif; ?>>

            <div class="creditCardForm">
                <div class="heading">
                    <h1>Payment Information</h1>
                </div>
                <div class="payment">

                        <div class="form-group owner">
                            <label for="owner">Card Holder Name</label>
                            <input type="text" class="form-control" name="card_holder_name" id="card_holder_name">
                        </div>
                        <div class="form-group CVV">
                            <label for="cvv">CVV</label>
                            <input type="text" class="form-control" id="cvc" name="cvc">
                        </div>
                        <div class="form-group" id="card-number-field">
                            <label for="cardNumber">Card Number</label>
                            <input type="text" class="form-control" id="cardNumber" name="card_number">
                        </div>
                        <div class="form-group" id="expiration-date">
                            <label for="cardNumber">Expire at</label>
                            <input type="text" class="form-control" name="expire_date" id="expire_date" placeholder="MM/YY">
                        </div>
                        <div class="form-group" id="credit_cards">
                            <img src=<?php echo e(asset('images/visa.jpg')); ?>  id="visa">
                            <img src=<?php echo e(asset('images/mastercard.jpg')); ?>  id="mastercard">
                            <img src=<?php echo e(asset('images/amex.jpg')); ?>  id="amex">
                        </div>
                        <div class="form-group" id="pay-now">
                            <button type="submit" class="btn btn-default" id="confirm-purchase">Confirm</button>
                        </div>

                </div>
            </div>
        </div>



    </div>
</form>


    

    <script src=<?php echo e(asset('script/jquery.payform.min.js')); ?> charset="utf-8"></script>
    <script src=<?php echo e(asset('script/script.js')); ?> charset="utf-8"></script>
</body>

</html>
<?php /**PATH D:\Neptune_Projects\outstouce_project\biz-core\resources\views/auth/register.blade.php ENDPATH**/ ?>