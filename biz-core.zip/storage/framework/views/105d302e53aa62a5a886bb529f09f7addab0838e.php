

<?php $__env->startSection('content'); ?>
    <div>

        <div class="container-fluid homepage-inverse-header">
            <div class="container">
                <h1 class="homepage-inverse-header__title">
                    <?php echo e($biz->name); ?>

                </h1>
                <div class="row">
                    <div class="col-9">
                        <p class="homepage-inverse-header__intro">
                            <?php echo e($biz->biz_detail); ?>

                        </p>
                    </div>
                    <div class="col-3">
                        <?php if(Auth::check()): ?>
                            <div class="col-lg-12  m-1 ">
                                <?php if(Auth::user()->type->value == 'buyer'): ?>
                                    <form  method="POST" enctype="multipart/form-data"
                                        action="/proposals/upload-to-biz">
                                        <?php echo csrf_field(); ?>
                                        

                                        <div class="proposal-card">
                                            <div class="d-flex justify-content-center align-items-center" style="color:#000;">
                                                <label class="fw-bold fs-5" >My Proposal</label>
                                                <label class="switch m-3">
                                                    <input type="checkbox" id="isfile" name="isfile"
                                                        onclick="showHideFile(this)">
                                                    <span class="slider round"></span>
                                                </label>
                                                <label class="fw-bold fs-5">Select File</label>
                                            </div>

                                            <input type="hidden" name="biz_id" value=<?php echo e($biz->id); ?>>
                                            <input type="hidden" id="fielValue" name="type" value="my_proposal">
                                            <input type="file" id="file" name="file" style="display:none;">
                                            <select class="form-select" name="proposal_id" id="proposal"
                                                style="display:block;">
                                                <?php $__currentLoopData = $proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value=<?php echo e($proposal->id); ?>><?php echo e($proposal->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="d-flex justify-content-center">
                                                <input class="btn btn-primary d-block m-3" type="submit" value="Sent Proposal">
                                            </div>
                                        </div>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

        </div>

        <div class="container">
            <div class="row">

                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session()->get('message')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    
                <?php endif; ?>

                <div class="col-lg-9 price-card p-4 m-2">

                    <div class="row">
                        <div class="col-lg-6 " style="color:#000;">
                            <h3 class="fw-bold" >Price</h3>
                            <p><?php echo e($biz->actual_sale_price ?? "NA"); ?></p>
                        </div>
                        <div class="col-lg-6 " style="color:#000;">
                            <h3 class="fw-bold"  >Wish Sale Price</h3>
                           <p> <?php echo e($biz->wish_sale_price ?? "ND"); ?> </p> 
                        </div>
                    </div>



                </div>

                <div class="col-lg-9 card p-4 m-2">

                    <h3>Reason for Sale</h3>
                    <?php echo e($biz->reason_sale); ?>

                </div>



                </>

            </div>


            <script>
                function showHideFile(checkFile) {
                    var file = document.getElementById("file");
                    file.style.display = checkFile.checked ? "block" : "none";
                    document.getElementById("fielValue").value = checkFile.checked ? "select_file" : "my_proposal";
                    document.getElementById("proposal").style.display = checkFile.checked ? "none" : "block";
                }
            </script>
            </>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Neptune_Projects\outstouce_project\biz-core\resources\views/biz/show.blade.php ENDPATH**/ ?>