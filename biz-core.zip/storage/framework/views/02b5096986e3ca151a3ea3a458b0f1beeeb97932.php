

<?php $__env->startSection('user_content'); ?>
<div class="container">
    <div class="row">
    <?php $__currentLoopData = $bizs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3">
        <div class="custom-card">
            <div class="mini">
                <?php echo e($biz->created_at); ?>

            </div>
            <h5 class="title"><?php echo e($biz->name); ?></h5>
            <p class="body text-truncate" style="max-width: 200px;"><?php echo e($biz->biz_detail); ?></p>
            <div class="d-flex justify-content-start mt-3 mb-2">
                <a href="<?php echo e(route("biz.show",$biz->id)); ?>" class=" mx-3 font-weight-bold text-decoration-none text-dark">
                    See Detail
                </a>

            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Neptune_Projects\outstouce_project\biz-core\resources\views/biz/list.blade.php ENDPATH**/ ?>