

<?php $__env->startSection('content'); ?>
<div class="container-fluid homepage-inverse-header">
    <div class="container">
        <h1 class="homepage-inverse-header__title">
            Welcome to Outsource
        </h1>
        <p class="homepage-inverse-header__intro">
            The best place to find business services and information
        </p>
        <p class="homepage-inverse-header__intro homepage-inverse-header__intro--bold">
            Simpler, Clearer & Faster
        </p>
    </div>
    
</div>
<div class="container mt-3">
    <div class="row">
    <?php $__currentLoopData = $bizs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3">
        <div class="custom-card">
            <div class="mini">
                <?php echo e($biz->created_at); ?>

            </div>
            <h5 class="d-flex justify-content-between title"><?php echo e($biz->name); ?> 
            <div class="icon">
                <i class="fa-solid fa-angle-right"></i>
            </div>
            </h5>
            <p class="body text-truncate"><?php echo e($biz->biz_detail); ?></p>
            <div class="d-flex justify-content-start  py-3">
                <a href="<?php echo e(route("biz.show",$biz->id)); ?>" class=" mx-3 font-weight-bold text-decoration-none text-dark">
                    See Detail
                </a>
                
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Neptune_Projects\outstouce_project\biz-core\resources\views/welcome.blade.php ENDPATH**/ ?>