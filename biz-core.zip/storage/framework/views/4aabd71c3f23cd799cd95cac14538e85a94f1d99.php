

<?php $__env->startSection('dashboard_content'); ?>
    <div class="container">
        <form method="POST"
            action="<?php echo e(route('proposal.biz.accept', ['proposal' => $proposal->id, 'biz_id' => $biz->id])); ?>">
            <?php echo csrf_field(); ?>
            <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-outline-primary m-2">Accept</button>
                <button type="button" class="btn btn-outline-danger m-2">Decline</button>
            </div>

        </form>

        <?php echo $proposal->description; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Neptune_Projects\outstouce_project\biz-core\resources\views/proposal/show.blade.php ENDPATH**/ ?>