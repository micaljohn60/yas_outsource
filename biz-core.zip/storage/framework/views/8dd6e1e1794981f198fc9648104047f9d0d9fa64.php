<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Outsource Project</title>
    <script src="https://kit.fontawesome.com/0e4c6fcdab.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link href="<?php echo e(asset('css/side_bar_style.css')); ?>" rel="stylesheet">
  

    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <link href="https://cdn.quilljs.com/1.3.6/quill.bubble.css" rel="stylesheet">





    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
        
</head>

<body>
    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Out Source</h3>
            </div>

            <ul class="list-unstyled components">

                <li class="<?php echo e((request()->is('buyer/dashboard')) ? 'active' : ''); ?>">
                    <a href="<?php echo e(Auth::user()->type->value == 'buyer' ?
                    route("buyer.dashboard")
                    :
                    route("seller.dashboard")); ?>" aria-expanded="false" class="dropdown-toggle"> <i class="fa-solid fa-chart-line mx-3 ml-5"></i>Dashboard</a>
                </li>

                

                <?php if(Auth::user()->type->value == 'buyer' ): ?>
                <li class="<?php echo e((request()->is('proposals/create')) ? 'active' : ''); ?>">
                    <a href="<?php echo e(route("proposal.create")); ?>"><i class="fa-solid fa-plus mx-3"></i> Create Proposal</a>
                </li>
                <li class="<?php echo e((request()->is('proposals')) ? 'active' : ''); ?>">
                    <a href="<?php echo e(route("proposal.index")); ?>" ><i class="fa-regular fa-file-lines mx-3"></i> My Proposal Lists</a>
                </li>
                <?php elseif(Auth::user()->type->value == 'seller'): ?>
                <li>
                    <a href="<?php echo e(route('biz.create')); ?>"><i class="fa-solid fa-plus mx-3"></i> Create Biz</a>
                </li>
                <?php endif; ?>
                
                <li class="<?php echo e((request()->is('notifications')) ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('notifications.index')); ?>"><i class="fa-regular fa-bell mx-3"></i> Notifications</a>
                </li>
              
                    
                    <form action="<?php echo e(route('logout')); ?>" method="POST" >
                        <?php echo csrf_field(); ?>
                        <button class="logout-button">
                            <i class="fa-solid fa-right-from-bracket mx-3"></i>
                            Logout
                        </button>
                    </form>
                    
                
        </nav>
        

        <!-- Page Content  -->
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse"
                        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                       
                            <li class="nav-item">
                                <a class="nav-link" href="#">Language</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#"><?php echo e(Auth::user()->first_name); ?></a>
                            </li>
                       
                        </ul>
                    </div>
                </div>
            </nav>
            <?php echo $__env->yieldContent('dashboard_content'); ?>
           
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8"
            crossorigin="anonymous"></script>
      <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>

      
    <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
    
        <script>
            
            $(document).ready(function () {
                $('#datepicker').datepicker();
                $('#example').DataTable();
                $('#proposal').DataTable();
                $('#sidebarCollapse').on('click', function () {
                    $('#sidebar').toggleClass('active');
                });
            });


        </script>
</body>

</html><?php /**PATH D:\Neptune_Projects\outstouce_project\biz-core\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>