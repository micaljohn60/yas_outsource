

<?php $__env->startSection('dashboard_content'); ?>
<div class="d-flex justify-content-end">
    <button class="btn btn-primary">Create New Proposal + </button>
</div>

<div class="row"> 
    
        <?php $__currentLoopData = $proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-2">
        <a href="<?php echo e(route('proposal.edit',$proposal->id)); ?>">
            <div class="card" style="width: 15rem;">
                <div class="card-body">
                  <h5 class="card-title d-inline-block text-truncate" style="max-width: 10rem;"><?php echo e($proposal->title); ?></h5>
                  
                  
                </div>
                <div class="d-flex justify-content-end pe-3">
                  <p><small id="time"><?php echo e($proposal->created_at); ?></small></p>
                </div>
            </div>
        </a>
      </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script>
    var getDateTime = document.getElementById('time').textContent;
    var getDescription = document.getElementById('description').textContent;
    const  splitData = getDateTime.split(" ");
    document.getElementById("time").innerText = splitData[0];
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Neptune_Projects\outstouce_project\biz-core\resources\views/proposal/list.blade.php ENDPATH**/ ?>