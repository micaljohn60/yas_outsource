<?php

namespace App\Enums;

enum UserAccessType: string
{
    case FREE = 'FREE';
    case PREMIUM = 'PREMIUM';
}
